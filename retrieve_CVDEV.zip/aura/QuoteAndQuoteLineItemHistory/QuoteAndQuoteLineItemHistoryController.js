({
	doInit : function(component, event, helper) {
		helper.getHistory(component, event, helper);
	}
})