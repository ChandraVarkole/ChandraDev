({
    getHistory : function(component, event, helper){
        var action = component.get("c.getHistory");
        action.setParams({
            historyParentId: component.get("v.recordId")    
        });
        action.setCallback(this, function(response) {
            console.log(response.getReturnValue());
            var state = response.getState();
            console.log(state);
            if (state === "SUCCESS") {
                let history=[];
                let results = response.getReturnValue();
                for(let i=0;i<results['quoteHeaderHistory'].length;i++){
                    let ob={
                        CreatedById:results['quoteHeaderHistory'][i].CreatedById,
                        CreatedByName:results['quoteHeaderHistory'][i].CreatedBy.Name,
                        CreatedDate:results['quoteHeaderHistory'][i].CreatedDate,
                        Id:results['quoteHeaderHistory'][i].Id,
                        IsDeleted:results['quoteHeaderHistory'][i].IsDeleted,
                        NewValue:results['quoteHeaderHistory'][i].NewValue,
                        Field:results['quoteHeaderHistory'][i].hasOwnProperty('Field')?results['quoteHeaderHistory'][i].Field:'',
                        ParentId:results['quoteHeaderHistory'][i].hasOwnProperty('ParentId')?results['quoteHeaderHistory'][i].ParentId:'',
                        ParentName:results['quoteHeaderHistory'][i].hasOwnProperty('ParentId')?results['quoteHeaderHistory'][i].Parent.Name:'',
                        OldValue:results['quoteHeaderHistory'][i].hasOwnProperty('OldValue')?results['quoteHeaderHistory'][i].OldValue:'',
                        Type:'Quote Header'
                    };
                    history.push(ob);
                }
                for(let i=0;i<results['quoteLevelHeaderHistory'].length;i++){
                    let ob={
                        CreatedById:results['quoteLevelHeaderHistory'][i].CreatedById,
                        CreatedByName:results['quoteLevelHeaderHistory'][i].CreatedBy.Name,
                        CreatedDate:results['quoteLevelHeaderHistory'][i].CreatedDate,
                        Id:results['quoteLevelHeaderHistory'][i].Id,
                        IsDeleted:results['quoteLevelHeaderHistory'][i].IsDeleted,
                        NewValue:results['quoteLevelHeaderHistory'][i].NewValue,
                        Field:results['quoteLevelHeaderHistory'][i].hasOwnProperty('Field')?results['quoteLevelHeaderHistory'][i].Field:'',
                        ParentId:results['quoteLevelHeaderHistory'][i].hasOwnProperty('ParentId')?results['quoteLevelHeaderHistory'][i].ParentId:'',
                        ParentName:results['quoteLevelHeaderHistory'][i].hasOwnProperty('ParentId')?results['quoteLevelHeaderHistory'][i].Parent.Name:'',
                        OldValue:results['quoteLevelHeaderHistory'][i].hasOwnProperty('OldValue')?results['quoteLevelHeaderHistory'][i].OldValue:'',
                        Type:'Quote Header Line Item'
                    };
                    history.push(ob);
                }
                console.log(results);
                console.log(history);
                component.set("v.componentHistory",history);
                
            } else if (status === "INCOMPLETE") {
                //console.log("No response from server or client is offline.");
                this.showToast(component, "Error", "Error", "Incomplete Transaction Try again.");
                // Show offline error
            } else if (state === "ERROR") {
                var errors = response.getError();
                if (errors) {
                    if (errors[0] && errors[0].message) {
                        // console.log("Error message: " + errors[0].message);
                        this.showToast(component, "Error", "Error", errors[0].message);
                    }
                } else {
                    //console.log("Unknown error");
                    this.showToast(component, "Error", "Error", "Unknown error Occurred Try After SomeTime.");
                }
                
            }
        });
        $A.enqueueAction(action);
    }
})