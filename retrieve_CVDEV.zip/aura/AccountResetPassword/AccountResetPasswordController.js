({
	resetSfccPassword : function(component, event, helper) {
		var action = component.get("c.resetAccountPassword");
        action.setParams({ accId : component.get("v.recordId") });
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                let resp = response.getReturnValue();
                if(resp.status==='SUCCESS'){
                    component.set("v.status", resp.status);
                    component.set("v.message", "Link to reset password has been sent to \""+resp.email+"\"");
                }
                else{
                    component.set("v.status", resp.status);
                    component.set("v.message", resp.error);
                }
            }
            else if (state === "INCOMPLETE") {
                alert("INCOMPLETE");
            }
            else if (state === "ERROR") {
                var errors = response.getError();
                if (errors) {
                    if (errors[0] && errors[0].message) {
                        alert("Error message: " + 
                                 errors[0].message);
                    }
                } else {
                    alert("Unknown error");
                }
            }
        });

        // optionally set storable, abortable, background flag here

        // A client-side action could cause multiple events, 
        // which could trigger other events and 
        // other server-side action calls.
        // $A.enqueueAction adds the server-side action to the queue.
        $A.enqueueAction(action);
	}
})