({
    
    
    saveandcreate: function(component, event, helper, issave) {
        component.set("v.loaded", true);
        var listnew = component.get("v.insertList");
        console.log(listnew)
        var Quotedetails = {
            "accountID": component.get("v.AccId"),
            "opportunityId": component.get("v.OppId"),
            "InHandsDate": component.find("inhanddateId").get("v.value"),
            "DoNotShipBefore": component.find("DoNotShipBeforeId").get("v.value")
        }
        
        var action3 = component.get("c.saveandupdateQuote");
        action3.setParams({
            newList: JSON.stringify(component.get("v.insertList")),
            updateList: JSON.stringify(component.get("v.updatedList")),
            QuoteId: component.get("v.quoteID"),
            QuoteDetails: JSON.stringify(Quotedetails)
        });
        
        action3.setCallback(this, function(response2) {
            console.log(response2.getReturnValue());
            var state = response2.getState();
            console.log(state);
            if (state === "SUCCESS") {
                var results = response2.getReturnValue();
                if ((results.newListupdated).length > 0) {
                    console.log(results.newListupdated != null);
                    let ResupdatedList = component.get("v.updatedList");
                    for (var i = 0; i < listnew.length; i++) {
                        for (var j = 0; j < (results.newListupdated).length; j++) {
                            if (listnew[i].itemnumber == results.newListupdated[j].Quote_Item_Number__c) {
                                console.log("get inside");
                                listnew[i].headerid = results.quoteId;
                                listnew[i].lineId = results.newListupdated[j].Id;
                                ResupdatedList.push(listnew[i]);
                            }
                        }
                    }
                    console.log("ResupdatedList");
                    console.log(ResupdatedList);
                    let emptylist = [];
                    component.set("v.insertList", emptylist);
                    component.set("v.updatedList", ResupdatedList);
                    console.log('total List');
                    console.log(component.get("v.updatedList"));
                    
                    console.log(component.get("v.insertList"));
                    component.set("v.quoteID", results.quoteId);
                    console.log(component.get("v.quoteID"));
                }
                console.log(results);
                component.set("v.loaded", false);
                if (issave) {
                    this.showToast(component, "Success!", "success", "Transaction Successfully Saved.");
                    helper.navigatetoobject(component, event, component.get("v.quoteID"));
                } else {
                    this.showToast(component, "Success!", "success", "The record has been updated successfully.");
                }
                
            } else if (status === "INCOMPLETE") {
                //console.log("No response from server or client is offline.");
                this.showToast(component, "Error", "Error", "Incomplete Transaction Try again.");
                // Show offline error
            } else if (state === "ERROR") {
                var errors = response.getError();
                if (errors) {
                    if (errors[0] && errors[0].message) {
                        // console.log("Error message: " + errors[0].message);
                        this.showToast(component, "Error", "Error", errors[0].message);
                    }
                } else {
                    //console.log("Unknown error");
                    this.showToast(component, "Error", "Error", "Unknown error Occurred Try After SomeTime.");
                }
                
            }
        });
        $A.enqueueAction(action3);
    },
    
    showToast: function(component, title, type, message) {
        try {
            var toastEvent = $A.get("e.force:showToast");
            toastEvent.setParams({
                "title": title,
                "type": type,
                "message": message
                
            });
            toastEvent.fire();
        } catch (Err) {
            console.log(Err);
        }
    },
    
    navigatetoobject: function(cmp, event, objectid) {
        try {
            var navEvt = $A.get("e.force:navigateToSObject");
            navEvt.setParams({
                "recordId": objectid,
                "slideDevName": "detail"
            });
            navEvt.fire();
        } catch (Err) {
            console.log(Err);
        }
    },
    
    showsection: function(component, event) {
        var tar = event.getSource();
        var section = component.find('sectionId');
        var content = component.find('accordion-details-01');
        if (tar.get("v.iconName") == "utility:down") {
            var tart = tar.set("v.iconName", 'utility:right');
            $A.util.removeClass(section, 'slds-is-open');
            content.set("v.aria-hidden", "false");
        } else {
            tar.set("v.iconName", 'utility:down');
            $A.util.addClass(section, 'slds-is-open');
            content.set("v.aria-hidden", "true");
        }
    },
    
    showsectioncustom: function(component, event) {
        var tar1 = event.getSource();
        var section2 = component.find('section2Id');
        var content2 = component.find('accordion-details-02');
        if (tar1.get("v.iconName") == "utility:down") {
            var tart1 = tar1.set("v.iconName", 'utility:right');
            $A.util.removeClass(section2, 'slds-is-open');
            content2.set("v.aria-hidden", "false");
        } else {
            tar1.set("v.iconName", 'utility:down');
            $A.util.addClass(section2, 'slds-is-open');
            content2.set("v.aria-hidden", "true");
        }
    },
    
    showsectionnoncustom: function(component, event) {
        var tar2 = event.getSource();
        var section3 = component.find('section3Id');
        var content3 = component.find('accordion-details-03');
        if (tar2.get("v.iconName") == "utility:down") {
            var tart2 = tar2.set("v.iconName", 'utility:right');
            $A.util.removeClass(section3, 'slds-is-open');
            content3.set("v.aria-hidden", "false");
        } else {
            tar2.set("v.iconName", 'utility:down');
            $A.util.addClass(section3, 'slds-is-open');
            content3.set("v.aria-hidden", "true");
        }
    },
    
    recordsFromSearchbar: function(cmp, event) {
        
        var lineobj = event.getParam("lineitems");        
        var num = parseInt('00010');
        var itmnum = cmp.get("v.itemnumber") + num;
        var lstinsert = cmp.get("v.insertList");
        if ((lineobj.UPK__c != "") && (lineobj.UPK__c != null)) {
            lineobj.itemnumber = itmnum.toString();           
            let customlist = cmp.get("v.Customlist");
            customlist.push(lineobj);
            cmp.set("v.Customlist", customlist);
            lstinsert.push(lineobj);
            cmp.set("v.insertList", lstinsert);
            console.log(cmp.get("v.Customlist"));
            console.log(cmp.get("v.insertList"));
            cmp.set("v.itemnumber", itmnum);
            
        } else{
            
            lineobj.itemnumber = itmnum.toString();
            let noncustom = cmp.get("v.NotCustomlist");
            noncustom.push(lineobj);
            cmp.set("v.NotCustomlist", noncustom);
            let lstinsert = cmp.get("v.insertList");
            lstinsert.push(lineobj);
            cmp.set("v.insertList", lstinsert);
            console.log(cmp.get("v.insertList"));
            cmp.set("v.itemnumber", itmnum);
        }
        //console.log(cmp.get("v.NotCustomlist"));
        
    },
    
    recordsFromTopList: function(cmp, event) {
        var prodId = event.getParam("productId");       
        var num1 = parseInt('00010');
        var itmnum1 = cmp.get("v.itemnumber") + num1;      
        if ((prodId.UPK__c != "") && (prodId.UPK__c != null)) {
            let lineobj1 = {
                "itemnumber": itmnum1.toString(),
                "Description": prodId.Description__c,
                "Name": prodId.ProductName__c,
                "ProductLocation__c": prodId.ProductURL__c,
                "Product_Id__c":prodId.Product_Id__c,
                "Quantity":1,
                "Tax":0,
                "Discount":0,
                "Total":0,
                "Price":0
            }
            
            let customlist1 = cmp.get("v.Customlist");
            customlist1.push(lineobj1);
            cmp.set("v.Customlist", customlist1);
            var insertlst = [];
            insertlst.push(lineobj1);
            cmp.set("v.insertList", insertlst);
            cmp.set("v.itemnumber", itmnum1);
        } else {
            let lineobj1 = {
                "itemnumber": itmnum1.toString(),
                "Description": prodId.Description__c,
                "Name": prodId.ProductName__c,
                "ProductLocation__c": prodId.ProductURL__c,
                "Product_Id__c":prodId.Product_Id__c,
                "Quantity":1,
                "Tax":0,
                "Discount":0,
                "Total":0,
                "Price":0
            }
            let noncustom1 = cmp.get("v.NotCustomlist");
            noncustom1.push(lineobj1);
            cmp.set("v.NotCustomlist", noncustom1);
            var insertlst1 = [];
            insertlst1.push(lineobj1);
            cmp.set("v.insertList", insertlst1);
            cmp.set("v.itemnumber", itmnum1);
        }
        console.log(cmp.get("v.NotCustomlist"));
    },
    getPricesFromFFc  : function(component,event,helper) {
        this.showSpinner(component);
      
        var action = component.get("c.getProducts");        
        action.setCallback(this, function(response){
            var state = response.getState();            
            if(state === "SUCCESS"){            
                let responseMap=[];
                let reponse=JSON.parse(response.getReturnValue()); 
                let currentPrice=[];
                console.log(reponse);
               
                for(let i=0;i<reponse.hits.length;i++){
                    let str=JSON.stringify(reponse.hits[i]);                    
                    responseMap[reponse.hits[i].represented_product.id]=JSON.parse(str);                    
                }
                
                /*                  
                for(let i=0;i<reponse.hits.length;i++){
                    let str=JSON.stringify(reponse.hits[i]);
                     currentPrice.push(JSON.parse(str));
                     responseMap[reponse.hits[i].represented_product.id]=JSON.parse(str);
                   
                    //reponse.hits[i].price='';
                   
                }
                component.set("v.responseMap",currentPrice);
                console.log(component.get("v.responseMap"));
                */
                this.hideSpinner(component);
            }else if (state === "ERROR") {
                console.log(response.getError());
                var errors = response.getError();
                if (errors) {
                    if (errors[0] && errors[0].message) {
                        $A.get("e.force:showToast").setParams({
                            "title": "ERROR",
                            "message": "Error message: " + errors[0].message,
                            "type": "error"
                        }).fire();
                    }
                }else {	                    
                    $A.get("e.force:showToast").setParams({
                        "title": "ERROR",
                        "message": "Unknown error",
                        "type": "error"
                    }).fire();
                }
            }    
        });
        $A.enqueueAction(action);
    },
    createBasketAndAddProduct:function(component,event,helper){
        let NotCustomlist=component.get("v.NotCustomlist");
        let productBundle=[];
        let productIdVsProduct=[];
        for(let i=0;i<NotCustomlist.length;i++){
            productBundle.push({
                product_id:NotCustomlist[i].Product_Id__c,
                quantity:NotCustomlist[i].Quantity
            });
            productIdVsProduct[NotCustomlist[i].Product_Id__c]=NotCustomlist[i];
        }
      
      
        var action = component.get("c.getResponseForAddedProducts"); 
        action.setParams({
                "responseProducts": JSON.stringify(productBundle)
            });
        action.setCallback(this, function(response){
            var state = response.getState();            
            if(state === "SUCCESS"){                           
                let priceAndPromotion=JSON.parse(response.getReturnValue());
                console.log(priceAndPromotion);
                let productsTotal=component.get("v.productTotal");
                for(let i=0;i<priceAndPromotion.product_items.length;i++){
                    productIdVsProduct[priceAndPromotion.product_items[i].product_id].Tax=10;
                    productIdVsProduct[priceAndPromotion.product_items[i].product_id].Total=priceAndPromotion.product_items[i].price_after_item_discount+10;
                    productIdVsProduct[priceAndPromotion.product_items[i].product_id].Price=priceAndPromotion.product_items[i].price;
                    productIdVsProduct[priceAndPromotion.product_items[i].product_id].Discount=parseInt(priceAndPromotion.product_items[i].price)-parseInt(priceAndPromotion.product_items[i].price_after_item_discount);
                    productsTotal.Subtotal+= Math.round(productIdVsProduct[priceAndPromotion.product_items[i].product_id].Price);                  
                   	productsTotal.DiscountItem+=parseInt(priceAndPromotion.product_items[i].price)!=parseInt(priceAndPromotion.product_items[i].price_after_item_discount)?productIdVsProduct[priceAndPromotion.product_items[i].product_id].Quantity:0;
                    productsTotal.Total+=Math.round(productIdVsProduct[priceAndPromotion.product_items[i].product_id].Total);
                    productsTotal.Tax+=productIdVsProduct[priceAndPromotion.product_items[i].product_id].Tax;
                }
                
              
                
                let finalResult=[];
                for(let key in productIdVsProduct){                    
                   finalResult.push(productIdVsProduct[key]);
                }
                component.set("v.productTotal",productsTotal);
                component.set("v.NotCustomlist",finalResult);
                this.hideSpinner(component);
            }else if (state === "ERROR") {
                console.log(response.getError());
                var errors = response.getError();
                if (errors) {
                    if (errors[0] && errors[0].message) {
                        $A.get("e.force:showToast").setParams({
                            "title": "ERROR",
                            "message": "Error message: " + errors[0].message,
                            "type": "error"
                        }).fire();
                    }
                }else {	                    
                    $A.get("e.force:showToast").setParams({
                        "title": "ERROR",
                        "message": "Unknown error",
                        "type": "error"
                    }).fire();
                }
            }    
        });
        $A.enqueueAction(action);
        
        
    },
    hideSpinner :function(component){     
        var cmpTarget = component.find('mySpinner');
        $A.util.addClass(cmpTarget, 'slds-hide');
    },showSpinner :function(component){
        var cmpTarget = component.find('mySpinner');
        $A.util.removeClass(cmpTarget, 'slds-hide');
        
    },
    
    
})