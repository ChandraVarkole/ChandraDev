({
    doInit: function(component, event, helper) {
        // helper.getPricesFromFFc(component,event,helper);	
        try {
            
            
            window.addEventListener("message", function(event) {
                //console.log(event.data);
                var v = JSON.stringify(event.data);
                var m = v.replace('}"', '}');
                var o = m.replace('"{', '{');
                var n = o.replace(/\\/g, "");
                let custmizerList = [];
                custmizerList = JSON.parse(n);
                var cusList = component.get("v.Customlist");
                for (var i = 0; i < cusList.length; i++) {
                    if (cusList[i].Id == component.get("v.customProductId")) {
                        cusList[i].jsondata__r = custmizerList;
                    }
                }
                component.set("v.Customlist", cusList);
            }, false);
        }
        catch (e) {
            if (e instanceof MyCustomError) {
                // Specific message for MyCustomError
                console.error(e.name + ' (code ' + e.code + '): ' + e.message);
                helper.showToast(component,e.name, "Error", e.message);
            } else {
                // Generic message for other types of error
                // (unreachable code in this sample)
                console.error(e.message);
                helper.showToast(component, "Error", "Error", e.message);
            }
        }
    },
    getPricesController: function(component, event, helper) {
        //console.log(component.get("v.orignalList"));
        //component.set("v.productList",component.get("v.orignalList"));
        helper.showSpinner(component);
        helper.createBasketAndAddProduct(component,event,helper);
    },
    changeicon: function(component, event, helper) {
        try {
            helper.showsection(component, event);
        } catch (e) {
            console.error(e.message);
            helper.showToast(component, "Error", "Error", e.message);
        }
        
        
    },
    
    changeicon1: function(component, event, helper) {
        try {
            helper.showsectioncustom(component, event);
        } catch (e) {
            console.error(e.message);
            helper.showToast(component, "Error", "Error", e.message);
        }
    },
    
    changeicon2: function(component, event, helper) {
        
        try {
            helper.showsectionnoncustom(component, event);
        } catch (e) {
            console.error(e.message);
            helper.showToast(component, "Error", "Error", e.message);
        }
        
    },
    
    handleComponentEvent: function(cmp, event, helper) {
        try {
            helper.recordsFromSearchbar(cmp, event);
        } catch (e) {
            console.error(e.message);
            helper.showToast(component, "Error", "Error", e.message);
        }
        
        
        
    },
    handleTopProductevent: function(cmp, event, helper) {
        try {
            helper.recordsFromTopList(cmp, event);
        } catch (e) {
            console.error(e.message);
            helper.showToast(component, "Error", "Error", e.message);
        }
        
    },
    
    showAll: function(cmp, event, helper) {
        cmp.set("v.cooler", true);
        cmp.set("v.custom", true);
        cmp.set("v.noncustom", true);
    },
    
    showCoolers: function(cmp, event, helper) {
        cmp.set("v.cooler", true);
        cmp.set("v.custom", false);
        cmp.set("v.noncustom", false);
    },
    showCustom: function(cmp, event, helper) {
        cmp.set("v.cooler", false);
        cmp.set("v.custom", true);
        cmp.set("v.noncustom", false);
    },
    showNonCustom: function(cmp, event, helper) {
        cmp.set("v.cooler", false);
        cmp.set("v.custom", false);
        cmp.set("v.noncustom", true);
    },
    AddEmblishment: function(component, event, helper) {
        var productkey = event.getSource().get("v.name");
        var n = productkey.lastIndexOf('/');
        var HvItemId = productkey.substring(n + 1);
        var UPK = productkey.substring(0, n);
        component.set("v.customProductId", HvItemId);
        var modalBody;
        $A.createComponent("c:ModalContent", {
            "UPK": UPK
        },
                           function(content, status) {
                               if (status === "SUCCESS") {
                                   modalBody = content;
                                   component.find('overlayLib').showCustomModal({
                                       header: "ADD EMBELLISHMENT",
                                       body: modalBody,
                                       showCloseButton: true,
                                       cssClass: "slds-modal_large",
                                       closeCallback: function() {
                                           alert('You closed the alert!');
                                       }
                                   }).then(function(overlay) {
                                       component.set('v.overlay', overlay);
                                   });
                               }
                           });
    },
    
    saveQuoteHeader: function(component, event, helper) {
        try {
            var issave = true;
            helper.saveandcreate(component, event, helper, issave);
        } catch (e) {
            console.error(e.message);
            helper.showToast(component, "Error", "Error", e.message);
        }
        
        
    },
    
    saveandContinueQuoteDetails: function(component, event, helper) {
        try {
            var issave = false;
            helper.saveandcreate(component, event, helper, issave);
        } catch (e) {
            console.error(e.message);
            helper.showToast(component, "Error", "Error", e.message);
        }
        
    },
    getPricing:function(component,event,helper){
        if(event.getSource().getLocalId()=='getPriceButton'){
            component.set("v.getPriceButtonClicked",true);
        }    
        if(event.getSource().getLocalId()=='getPriceButton' ||component.get("v.getPriceButtonClicked")==true ){
            let NotCustomlistTemp=component.get("v.NotCustomlist");
            let reponse=component.get("v.responseMap");
            let responseObj=[];
            let productsTotal=component.get("v.productTotal");
            console.log(productsTotal);
            for(let i=0;i<reponse.length;i++){
                let str=JSON.stringify(reponse[i]);                    
                responseObj[reponse[i].represented_product.id]=JSON.parse(str);                    
            }      
            // debugger;       
            for(let i=0;i<NotCustomlistTemp.length;i++){           
                if(NotCustomlistTemp[i].Product_Id__c!='' && NotCustomlistTemp[i].Product_Id__c!=undefined){
                    NotCustomlistTemp[i].Price=responseObj[NotCustomlistTemp[i].Product_Id__c].price;
                    let totalPrice=parseInt(NotCustomlistTemp[i].Price)*parseInt(NotCustomlistTemp[i].Quantity);
                    let totalTax=totalPrice*NotCustomlistTemp[i].Tax;                
                    NotCustomlistTemp[i].Total=totalPrice+totalTax;
                    
                    productsTotal.Subtotal+=totalPrice;                   
                    productsTotal.Tax+=totalTax;
                    productsTotal.Total+=NotCustomlistTemp[i].Total;
                    
                }
            }
            component.set("v.getPriceButtonClicked",true);
            component.set("v.NotCustomlist",NotCustomlistTemp);
            component.set("v.productTotal",productsTotal);
        }
    }
    
})